# Changelog

All Notable changes to Packager will be documented in this file.

## Version 2.2
- Support laravel 6
- Support difference key
- Support dynamic options on runtime

## Version 2.0
- Optimize source code
- Support display multiple captcha on page

## Version 1.0
Everything is brand new!